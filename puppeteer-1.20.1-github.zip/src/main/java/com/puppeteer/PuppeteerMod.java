package com.puppeteer;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.server.level.ServerPlayer;

public final class PuppeteerMod implements ModInitializer {
    public static final String MOD_ID = "puppeteer";

    @Override
    public void onInitialize() {
        PuppeteerItems.initialize();

        UseEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            if (!player.getItemInHand(hand).is(PuppeteerItems.PUPPETEER_WAND)) {
                return InteractionResult.PASS;
            }

            if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
                if (entity instanceof Mob mob) {
                    PuppeteerControl.togglePuppet(serverPlayer, mob);
                } else {
                    PuppeteerControl.message(serverPlayer, "That entity can't be puppeteered.");
                }
            }

            // Consume the interaction on both sides so the mob's normal interaction
            // (mounting, trading, opening a menu, etc.) doesn't also happen.
            return InteractionResult.SUCCESS;
        });

        ServerTickEvents.END_SERVER_TICK.register(PuppeteerControl::tick);
    }
}
