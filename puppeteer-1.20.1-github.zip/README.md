# Puppeteer — Fabric mod for Minecraft 1.20.1

Puppeteer adds a magic wand that recruits standard Minecraft `Mob` entities into a small group and gives the group simple orders. Built for **Minecraft Java Edition 1.20.1**, **Fabric**, and **Java 17**.

## Features

- Adds the **Puppeteer's Wand** to the Tools & Utilities creative tab.
- Right-click a `Mob` with the wand to recruit it. Right-click a mob you own again to release it.
- Right-click air with the wand to cycle the current group order:
  1. **Follow Me** — recruited mobs path toward you.
  2. **Stay** — recruited mobs stop navigating and hold position.
  3. **Roam Nearby** — recruited mobs wander around you.
  4. **Attack Nearby Hostiles** — recruited mobs target nearby hostile entities that their native AI can attack; players and recruited puppets are excluded.
- **Sneak + right-click air** to release all recruited mobs and reset the order.
- Up to 32 recruited mobs per player.

## Getting the wand

Use the Tools & Utilities creative tab, or run:

```mcfunction
/give @s puppeteer:puppeteer_wand
```

## Build locally

Requirements: JDK 17 and Gradle 8.7.

From the `puppeteer-mod` project folder, run:

```bash
gradle --no-daemon clean build
```

The remapped mod JAR will be in `build/libs/`.

## GitHub Actions build

The workflow lives at `.github/workflows/build.yml`. It runs on pushes, pull requests, and manual dispatch. After a successful run, open the run in GitHub Actions and download the `puppeteer-minecraft-1.20.1` artifact.

## Notes and limitations

- This is a common/server mod; the server must have it installed. For single-player, install it in the Fabric profile used by the world.
- It works with vanilla-style `Mob` subclasses, including many modded mobs. Custom entities can ignore vanilla navigation/targeting behavior.
- Attack Nearby Hostiles relies on the mob's existing combat AI. Passive creatures without attack goals generally cannot be made to fight by simply assigning a target.
- The project has been ported to 1.20.1-compatible source/API patterns, but no in-game test has been performed in this environment.
